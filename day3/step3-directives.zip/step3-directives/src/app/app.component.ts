import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <label for="cb">Show Terms & Conditions</label>
    <input id="cb" type="checkbox" (change)="show = !show"/> {{ show }}
    <br/>
    <ng-template [ngIf]="show">
      <h3>Terms & Conditions</h3>
      <hr>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi iure nobis inventore numquam? Facilis eius enim rerum, inventore perspiciatis laboriosam quis placeat vitae esse, reiciendis debitis, quaerat unde quo fugit!
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit, exercitationem? Dolorem aut repellendus unde fugiat, repudiandae ratione harum enim eius natus porro nesciunt ab nam pariatur quod similique saepe. Eaque.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi architecto aspernatur quisquam, ipsam deserunt ex sed dolore iste, fugiat ratione nobis voluptatum cum consectetur nostrum corrupti repellat quaerat a? Fugit.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Id ipsum eligendi error nam harum, architecto cupiditate ducimus animi, quae sequi recusandae consequatur nulla quis totam modi amet a provident voluptatum.
      </p>
    </ng-template>
    <!-- 
    <ul>
      <li>{{ heroes[0].title }}</li>
      <li>{{ heroes[1].title }}</li>
      <li>{{ heroes[2].title }}</li>
      <li>{{ heroes[3].title }}</li>
      <li>{{ heroes[4].title }}</li>
      <li>{{ heroes[5].title }}</li>
    </ul> 
    -->
    <div>
      <p class="hero" *ngFor="let hero of heroes; index as idx; first as fst; last as lst; odd as od; even as ev"> {{(idx + 1) +" : "+ hero.title }}
        <span *ngIf="fst"> First Hero </span>
        <span *ngIf="!lst && !fst"> In Between Hero </span>
        <span *ngIf="lst"> Last Hero </span>
        <span *ngIf="ev"> Odd Hero </span>
        <span *ngIf="od"> Even Hero </span>
      </p>
    </div>
    <input #rng type="range" [value]="rank" min="0" max="5" (input)="rank = rng.value" >
    <ul [ngSwitch]="rank">
      <li *ngSwitchCase="1">First Rank</li>
      <li *ngSwitchCase="2">Second Rank</li>
      <li *ngSwitchCase="3">Third Rank</li>
      <li *ngSwitchCase="4">Fourth Rank</li>
      <li *ngSwitchCase="5">Fifth Rank</li>
      <li *ngSwitchDefault >Not Ranked</li>
    </ul>
    <h2 ngNonBindable>{{ welcome to your life }}</h2>

    <!-- 
    <div class="hero" [class.redbox]="show" [class.orangebox]="rank > 3" >
        I am color changing box
    </div>
    -->
    <!--     
    <div [ngClass]="['hero', 'greenbox']" >
        I am color changing box
    </div> 
    -->
  <!--   <div [ngClass]="{ hero : show, orangebox : rank > 4 }" >
        I am color changing box
    </div> -->

    <div [ngStyle]="{ 'color' : show ? 'darkorange' : 'cyan', 'background-color' : rank == 2 ? 'darkslategrey' : 'yellow' }">
        welcome to your life
    </div>
  `,
  styles: [`
    .hero{
      background-color : #020122;
      width : 500px;
      padding : 10px;
      color : #F2F3AE;
      font-family : sans-serif;
      font-size : 20px
    }
   .greybox{
    border : 2px solid grey;
    width : 300px;
    padding : 20px;
    text-align : center;
    color : black;
  }
  .redbox{
    background-color : crimson;
    color : papayawhip;
  }
  .greenbox{
    background-color : darkseagreen;
    color : papayawhip;
  }
  .orangebox{
    background-color : darkorange;
    color : papayawhip;
  }
  `]
})
export class AppComponent {
  title = 'step3-directives';
  show = false;
  rank:any = 1;
  heroes = [{
        "sl": 1,
        "title": "Batman",
        "gender": "male",
        "firstname": "Bruce",
        "lastname": "Wayne",
        "city": "Gotham",
        "ticketprice": 123.4567,
        "releasedate": "1/26/2018",
        "poster": "assets/images/batman.jpg",
        "movieslist": [
            {
                "title": "Batman Begins",
                "poster": "assets/images/bat1_tn.jpg"
            }, {
                "title": "Dark Knight",
                "poster": "assets/images/bat2_tn.jpg"
            }, {
                "title": "Dark Knight Raises",
                "poster": "assets/images/bat3_tn.jpg"
            }
        ]
    
    },
    {
        "sl": 2,
        "title": "Superman",
        "gender": "male",
        "firstname": "Clark",
        "lastname": "Kent",
        "city": "Metropolis",
        "ticketprice": 178.6789,
        "releasedate": "1/27/2018",
        "poster": "assets/images/superman.jpg",
        "movieslist": [
            {
                "title": "Superman The Movie",
                "poster": "assets/images/super1_tn.jpg"
            }, {
                "title": "Superman Returns",
                "poster": "assets/images/super2_tn.jpg"
            }, {
                "title": "Superman Man of Steel",
                "poster": "assets/images/super3_tn.jpg"
            }
        ]
    
    },
    {
        "sl": 3,
        "title": "Ironman",
        "gender": "male",
        "firstname": "Tony",
        "lastname": "Stark",
        "city": "New York",
        "ticketprice": 122,
        "releasedate": "1/27/2018",
        "poster": "assets/images/ironman.jpg",
        "movieslist": [
            {
                "title": "Ironman",
                "poster": "assets/images/iron1_tn.jpg"
            }, {
                "title": "Ironman 2",
                "poster": "assets/images/iron2_tn.jpg"
            }, {
                "title": "Ironman 3",
                "poster": "assets/images/iron3_tn.jpg"
            }
        ]
    
    }, {
        "sl": 4,
        "title": "Phantom",
        "gender": "male",
        "firstname": "Kit",
        "lastname": "Walker",
        "city": "Bhangala",
        "ticketprice": 98.6456,
        "releasedate": "1/27/2018",
        "poster": "assets/images/phantom.jpg",
        "movieslist": [
            {
                "title": "The Phantom Slam Evilz",
                "poster": "assets/images/phantom1_tn.jpg"
            }
        ]
    
    }, {
        "sl": 5,
        "title": "Spiderman",
        "gender": "male",
        "firstname": "Peter",
        "lastname": "Parker",
        "city": "New York",
        "ticketprice": 1.3456,
        "releasedate": "9/26/2018",
        "poster": "assets/images/spiderman.jpg",
        "movieslist": [
            {
                "title": "Spiderman",
                "poster": "assets/images/spider1_tn.jpg"
            }, {
                "title": "Spiderman 2",
                "poster": "assets/images/spider2_tn.jpg"
            }, {
                "title": "Spiderman 3",
                "poster": "assets/images/spider3_tn.jpg"
            }
        ]
    },
    {
        "sl": 6,
        "title": "Wonder Women",
        "gender": "female",
        "firstname": "Princess",
        "lastname": "Diana",
        "city": "Amazon",
        "ticketprice": 341.3456978978,
        "releasedate": "11/26/2018",
        "poster": "assets/images/wonderwoman.jpg",
        "movieslist" : []
    }]
}
