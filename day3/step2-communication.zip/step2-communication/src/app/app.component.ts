import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.template.html',
  styles: []
})
export class AppComponent {
  title = 'step2-communication';
  message = "parent message";
  eventHandler(evt:any){
    // alert(evt);
    this.message = evt;
  }
}
