import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-childcomp',
 /*  inputs : ['childtitle'], */
  templateUrl: 'child.template.html',
  styles: [`
  .cursorbox{
    width : 300px;
    height : 300px;
    background-color : silver;
    border : 1px solid grey;
    margin : 10px auto ;
    text-align : center;
    line-height : 280px;
  }
  `]
})
export class ChildcompComponent {
  tempmessage = "default message"
  /* childtitle:string = "default"; */
  @Input('ct') childtitle:string = "default child title";

  @Output() childCompEvent:EventEmitter<any> = new EventEmitter();

  clickHandler(){
    this.childCompEvent.emit(this.tempmessage);
  }
  /* 
  keyHandler(evt:KeyboardEvent){
    console.log(evt.key)
  } 
  */
  keyHandler(evt:any){
    console.log(evt.key)
  }
  mouseHandler(evt:any){
    console.log(evt.clientX, evt.clientY)
  }
}
