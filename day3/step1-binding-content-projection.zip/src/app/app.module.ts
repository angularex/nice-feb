import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ChildComp } from './child.component';

@NgModule({
  /* this is where we declare all components, pipes, directives that will be used in our application */
  declarations: [ AppComponent, ChildComp ],
  /* this is where we import all modules that are required for our application */
  imports: [ BrowserModule, FormsModule ],
  /* this is where we provide all shared resources */
  providers: [],
  /* this is where we choose our main component */
  bootstrap: [ AppComponent ]
})
export class AppModule { }
