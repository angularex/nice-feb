import { Component } from "@angular/core";

@Component({
    selector : "app-child",
    template : `
    <div class="brdr">
        <h2>Child Component</h2>
        <ng-content select="ul"></ng-content>
        <ng-content select="h1"></ng-content>
        <ng-content select="p.second"></ng-content>
        <hr>
        <ng-content></ng-content>
    </div>
    `,
    styles : [`
        .brdr{
            border : 5px solid grey;
            padding : 20px;
        }
    `]
})
class ChildComp{

}

export { ChildComp }