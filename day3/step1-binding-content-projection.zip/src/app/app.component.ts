import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1> {{ 5+6 }} Angular Binding </h1>
  <h1> {{ title }} Angular Binding </h1>
  <h1> {{ title.toUpperCase() }} Angular Binding </h1>
  <h1> {{ title.length * 10 }} Angular Binding </h1>
  <h2> {{ title }} </h2>
  <h2 [innerHTML]="title"></h2>
  <h2 [innerText]="title"></h2>
  <h2 [textContent]="title"></h2>
  <h2 bind-textContent="title"></h2>
  <div [innerHTML]="temp"></div>
  <div [class]="boxclass">welcome to your life</div>
  <br>
  <div class="{{boxclass}}">welcome to your life</div>
  <br>    
  <div bind-class="boxclass">welcome to your life</div>
  <hr>
  <div class="greybox" [class]="boxclass">welcome to your life</div>
  <h4>{{ saymessage() }}</h4>
  <button (click)="changeColor()">Change The Color to Orange</button>
  <br>    
  <button on-click="changeColor()">Change The Color to Orange</button>
  <br>  
  <input #ti [value]="title" (input)="title = ti.value" >  
  <br>  
  <input [(ngModel)]="title" >  
  <app-child>
    <h1>Vijay</h1>
    <ul>
      <li>List Item 1</li>
      <li>List Item 2</li>
      <li>List Item 3</li>
      <li>List Item 4</li>
    </ul>
    <p class="first">
      First
      <br/>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Non optio perferendis, eius expedita dolorum placeat reiciendis porro, ipsa laborum amet sequi saepe sapiente vitae facilis id deleniti quis ex dicta?
    </p>
    <p class="second">
      Second
      <br/>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam, animi quibusdam praesentium at illum sunt numquam voluptatum facere molestiae nulla! Obcaecati itaque tenetur provident, sint eligendi aperiam reprehenderit ratione dolores.
    </p>
  </app-child>
  `,
  styles : [`
  
  .greybox{
    border : 2px solid grey;
    width : 300px;
    padding : 20px;
    text-align : center;
    color : black;
  }
  .redbox{
    background-color : crimson;
    color : papayawhip;
  }
  .greenbox{
    background-color : darkseagreen;
    color : papayawhip;
  }
  .orangebox{
    background-color : darkorange;
    color : papayawhip;
  }
  `]
})
export class AppComponent {
  title = 'Nice Pune';
  temp = '<ul><li>List 1</li><li>List 2</li></ul>';
  boxclass = "redbox";
  constructor(){
    setTimeout(()=>{
      this.boxclass = "greenbox";
    },2000)
  }

  saymessage(){
    return "Hello "+this.title;
  };

  changeColor(){
    this.boxclass = "orangebox";
  }
}
