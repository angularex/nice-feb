import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "gen"
})
class GenPipe implements PipeTransform{
    transform(agrs:any, gen:any, city:string) {
        // return "Mr "+agrs+" is "+gen
        if(gen === "female"){
            return "Miss "+agrs +" is from "+city;
        }else{
            return "Mr "+agrs +" is from "+city;
        }
    }
}

export { GenPipe }