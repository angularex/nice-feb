import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <input type="range" [(ngModel)]="quantity">Quantity is : {{ quantity }}
  <ul>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLinkActiveOptions]="{exact : true}" [routerLink]="['']">Home Page</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['batman']">Batman Page</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['superman']">Superman Page</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLinkActiveOptions]="{exact : true}" [routerLink]="['aquaman']">Aquaman Page</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['aquaman',quantity]">Aquaman Params</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['flash']">Flash Page</a> </li>
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['cyborg']">Cyborg Page</a> </li>
  </ul>
  <router-outlet></router-outlet>
  `,
  styles: [`
  li{
    list-style : none;
  }
    .listItem{
      background-color : crimson;
      display : block;
      color : papayawhip;
      padding : 10px;
      width : 150px;
      margin : 5px;
      text-align : center;
      text-decoration : none;
    }
    .selectedList{
      background-color : darkblue;
      color : papayawhip;
    }
  `]
})
export class AppComponent {
  quantity:any = 0;
  title = 'step8-routing';
}
