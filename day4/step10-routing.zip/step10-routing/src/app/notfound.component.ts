import { Component, OnInit } from '@angular/core';

@Component({
  template: `
     <h2> 404 Requested Page not found </h2>
  `,
  styles: [
  ]
})
export class NotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
