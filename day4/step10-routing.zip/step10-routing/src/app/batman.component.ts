import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  template: `
    <h2> Batman works! </h2>
    <input type="range" [(ngModel)]="batquantity">Quantity is : {{ batquantity }}
    <li> <a class="listItem" routerLinkActive="selectedList" [routerLink]="['/aquaman',batquantity]">Aquaman Params</a> </li>
    <br>
    <br>
    <button (click)="navigateToAquaman()">CLick to send 100 quantity</button>
  `,
  styles: [
  ]
})
export class BatmanComponent {
  batquantity:any = 0;
  constructor(private rtr:Router) { }

  navigateToAquaman(){
    this.rtr.navigate(['/aquaman',100]);
  }

}
