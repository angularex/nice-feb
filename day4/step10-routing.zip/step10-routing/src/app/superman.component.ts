import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <h2> Superman works! </h2>
  `,
  styles: [
  ]
})
export class SupermanComponent {
}
