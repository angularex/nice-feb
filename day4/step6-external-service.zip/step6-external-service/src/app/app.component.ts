import { Component } from '@angular/core';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Data from External Resources</h1>
      <app-users [data]="tempdata"></app-users>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step6-external-service';
  tempdata:any = [];
  constructor(private us:UserService){
    // this.tempdata = this.us.getdata();
    this.us.getdata().subscribe((res)=> this.tempdata = res);
  }
}
