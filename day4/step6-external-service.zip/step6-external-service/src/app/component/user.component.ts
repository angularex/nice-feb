import { Component, Input } from "@angular/core";

@Component({
    selector : "app-users",
    template : `
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>User id</th>
                    <th>Name</th>
                    <th>User Name</th>
                    <th>eMail</th>
                    <th>phone</th>
                    <th>Web Address</th>
                </tr>
            </thead>
            <tbody>
                <tr *ngFor="let user of userdata">
                    <td>{{ user.id }}</td>
                    <td>{{ user.name }}</td>
                    <td>{{ user.username }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.phone }}</td>
                    <td>{{ user.website }}</td>
                </tr>
            </tbody>
        </table>
    `
})
export class UserComp{
    @Input('data') userdata:any;
}