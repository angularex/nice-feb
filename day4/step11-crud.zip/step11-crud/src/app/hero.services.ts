import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class HeroService{
    
    constructor(private http:HttpClient){}

    serverurl = "http://localhost:5050";

    getHeroData(){
        return this.http.get(this.serverurl+"/data");
    }
    postHeroData(nhero:any){
        return this.http.post(this.serverurl+"/data", nhero);
    }
    getHeroToEdit(hid:any){
        return this.http.get(this.serverurl+"/edit/"+hid);
    }
    postHeroAfterEdit(hero:any){
        return this.http.post(this.serverurl+"/edit/"+hero._id, hero);
    }
    deleteHero(hid:any){
        return this.http.delete(this.serverurl+"/delete/"+hid);
    }
    // read
    // write
    // read to update
    // update
    // delete
}