import { Component } from '@angular/core';
import { HeroService } from './hero.services';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
    <h1>CRUD Application with MongoDB</h1>
    <div  *ngIf="!showEditBox">
      <h2>Add Hero</h2>
      <div class="mb-3">
        <label for="htitle" class="form-label">Title</label>
        <input [(ngModel)]="hero.title" class="form-control" id="htitle">
      </div>
      <div class="mb-3">
        <label for="hfname" class="form-label">First Name</label>
        <input [(ngModel)]="hero.firstname" class="form-control" id="hfname">
      </div>
      <div class="mb-3">
        <label for="hlname" class="form-label">Last Name</label>
        <input [(ngModel)]="hero.lastname" class="form-control" id="hlname">
      </div>
      <div class="mb-3">
        <label for="hcity" class="form-label">City</label>
        <input [(ngModel)]="hero.city" class="form-control" id="hcity">
      </div>
      <button (click)="addHeroHandler()" class="btn btn-primary">Add Hero</button>
    </div>


    <div *ngIf="showEditBox">
      <h2>Edit Hero</h2>
      <div class="mb-3">
        <label for="htitle" class="form-label">Edit Title</label>
        <input [(ngModel)]="edit_hero.title" class="form-control" id="htitle">
      </div>
      <div class="mb-3">
        <label for="hfname" class="form-label">Edit First Name</label>
        <input [(ngModel)]="edit_hero.firstname" class="form-control" id="hfname">
      </div>
      <div class="mb-3">
        <label for="hlname" class="form-label">Edit Last Name</label>
        <input [(ngModel)]="edit_hero.lastname" class="form-control" id="hlname">
      </div>
      <div class="mb-3">
        <label for="hcity" class="form-label">Edit City</label>
        <input [(ngModel)]="edit_hero.city" class="form-control" id="hcity">
      </div>
      <button (click)="updateHeroInfoHandler()" class="btn btn-primary">Update Hero</button>
    </div>

    <div>
      <h2>Hero List</h2>
      <table class="table table-responsive table-hover">
      <thead>
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>City</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of herolist; index as idx">
          <td>{{ idx + 1 }}</td>
          <td>{{ hero.title }}</td>
          <td>{{ hero.firstname }}</td>
          <td>{{ hero.lastname }}</td>
          <td>{{ hero.city }}</td>
          <td>
            <button (click)="editHeroHandler(hero._id)" class="btn btn-warning">Edit</button>
          </td>
          <td>
            <button (click)="deleteHeroHandler(hero._id)" class="btn btn-danger">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    </div>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step7-crud';
  hero:any = {
    title : "",
    firstname : "",
    lastname : "",
    city : ""
  }
  showEditBox = false;
  edit_hero:any = {
    id : "",
    title : "",
    firstname : "",
    lastname : "",
    city : ""
  }
  herolist:any = [];
  constructor(private hs:HeroService){}
  refresh(){
    this.hs.getHeroData().subscribe( res => this.herolist = res );
  }
  ngOnInit(){
    this.refresh()
  }
  addHeroHandler(){
    this.hs.postHeroData(this.hero).subscribe( res => {
      // console.log( res );
      this.hero = {
        title : "",
        firstname : "",
        lastname : "",
        city : ""
      };
      this.refresh()
    })
  }

  editHeroHandler(hid:any){
    this.hs.getHeroToEdit(hid).subscribe(res => {
      this.edit_hero = res; 
      this.showEditBox = true;
    });
  }
  deleteHeroHandler(hid:any){
    this.hs.deleteHero(hid).subscribe(res => this.refresh() )
  }

  updateHeroInfoHandler(){
     this.hs.postHeroAfterEdit(this.edit_hero).subscribe( res => {
      this.edit_hero = {
          id : "",
          title : "",
          firstname : "",
          lastname : "",
          city : ""
        };
        this.refresh();
        this.showEditBox = false;
     })
  }
}
