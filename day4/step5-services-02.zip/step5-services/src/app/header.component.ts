import { Component, Input } from '@angular/core';
import { HeroService } from './services/hero.service';

@Component({
  selector: 'app-header',
  template: `
  <h2>{{ compversion }}</h2>
    <ul class="nav justify-content-center">
      <li class="nav-item"  *ngFor="let hero of heroeslist">
        <a class="nav-link" href="#">{{ hero.title }}</a>
      </li>
   </ul>

  `,
  styles: [
  ]
})
export class HeaderComponent {
  @Input('data') heroeslist:any;
  @Input('version') compversion = 0;
 /*  constructor( private hs:HeroService ){
    this.heroeslist = this.hs.getdata();
    this.compversion = this.hs.getversion();
  } */
 
}
