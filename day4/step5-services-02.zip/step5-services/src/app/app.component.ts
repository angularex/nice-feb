import { Component } from '@angular/core';
import { Hero } from './hero.model';
import { HeroService } from './services/hero.service';

@Component({
  selector: 'app-root',
  template: `
   <div class="container">
   <h1>Angular Services </h1>
   <app-header [data]="heroeslist" [version]="compversion" ></app-header>
   <hr>
   <app-grid [data]="heroeslist" [version]="compversion" ></app-grid>
   </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step4-pipes';
  heroeslist:Array<Hero> = [];
  compversion = 0;
  // appdata:Array<Hero> = [];
  constructor(private hs:HeroService ){
    this.heroeslist = this.hs.getdata();
    this.compversion = this.hs.getversion();
  }
}
