export class Hero{
    sl:number = 0;
    title:string = "";
    gender:string = "";
    firstname:string = "";
    lastname:string = "";
    city:string = "";
    poster:string = "";
    releasedate:string = "";
    ticketprice:any = "";
    movieslist:Array<any> = [""];
}