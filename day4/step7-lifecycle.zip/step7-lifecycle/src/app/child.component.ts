import { Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  template: ` 
  <h2> Child Component </h2> 
  <h3>Message is | {{ message }} </h3>
  `,
})
export class ChildComponent implements OnInit, OnChanges, OnDestroy {
  @Input() message:string = "default message";
  constructor(){
    console.log("ChildComponent's constructor was called")
  }
  ngOnInit(){
    console.log("ChildComponent's ngOnInit was called");
  }
  ngOnChanges(){
    console.log("ChildComponent's ngOnChanges was called");
  }
  ngOnDestroy(){
    console.log("ChildComponent's ngOnDestroy was called");
  }
}
