import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>App Component</h1>
    <hr>
    <label for="">Message for child</label>
    <input [(ngModel)]="appmessage">
    <button (click)="show = !show">Show / Hide</button>
    <app-child *ngIf="show" [message]="appmessage"></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step7-lifecycle';
  show = true;
  appmessage = "default app message";
}
