import { Component } from "@angular/core";

@Component({
    selector : "app-box",
    template : `
    <article>
        <input #col type="color" (change)="selectedcolor = col.value">
        <h3>Color Me : {{ selectedcolor }}</h3>
        <div [style.backgroundColor]="selectedcolor"></div>
    </article>
    `,
    styles : [`
        article{
            width : 200px;
            height : 200px;
            border : 2px solid grey;
            padding : 5px;
            float : left;
            margin : 10px;
        }
        article div{
            height : 100px;
        }
    `]
})
export class BoxComp{
    selectedcolor:any = "#000000";
}