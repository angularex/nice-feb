import { Directive } from "@angular/core";

@Directive({
    selector : "nice",
})
export class NiceRainbow{
    
};

/*
tag directive
<ng-content>
<ng-template>

attribute directives
*ngFor
*ngIf
[ngSwitch]
[ngClass]
[ngStyle]
ngNonBindable
[(ngModel)]


*/