import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BoxComp } from './components/box.component';
import { NiceRainbow } from './directives/nicerainbow.directive';
import { CountPipe } from './pipes/count.pipe';

@NgModule({
  declarations: [
    AppComponent, BoxComp, CountPipe, NiceRainbow
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
