import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Customize Angular</h1>
    <hr>
    <app-box></app-box>
    <app-box></app-box>
    <app-box></app-box>
    <div style="clear: both;"></div>
    <p>{{ "Welcome" | count }} </p>
    <p>{{ "To" | count }} </p>
    <p>{{ "Your" | count }} </p>
    <p>{{ "Life" | count }} </p>
  `,
  styles: []
})
export class AppComponent {
  title = 'step8-custom';
}
