import { Component } from "@angular/core";

@Component({
    selector : 'app-temp-form',
    template : `
     <div>
      <h2>Template Driven Form</h2>
      <form #myform="ngForm" action="#" method="get" (submit)="formSubmitHandler(myform, $event)">
      <div class="mb-3">
          <label for="username" class="form-label">User Name</label>
          <input name="username" #uname="ngModel" required [(ngModel)]="userdata.name" type="text" class="form-control" id="username" >
          <div *ngIf="uname!.invalid && uname!.touched" class="form-text err">User Name is Invalid</div>
        </div>
        <div class="mb-3">
          <label for="userage" class="form-label">User Age</label>
          <input name="userage" #uage="ngModel" [(ngModel)]="userdata.age" type="number" min="18" max="90" class="form-control" id="userage" >
          <div *ngIf="uage!.invalid && uage!.touched && userdata.age < '18'" class="form-text err">You are too young to join us</div>
          <div *ngIf="uage!.invalid && uage!.touched && userdata.age > '90'" class="form-text err">You are too old to join us</div>
        </div>
        <div class="mb-3">
          <label for="useremail" class="form-label">Email address</label>
          <input name="useremail" #mail="ngModel" pattern=".+@.+" required [(ngModel)]="userdata.email" type="email" class="form-control" id="useremail" >
          <div *ngIf="mail.invalid && mail.touched" class="form-text err">eMail id is Invalid</div>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
      </form>
     </div> 
     <ul>
      <li>{{ userdata.name || '' }}
      {{ userdata.age || '' }}
      {{ userdata.email || '' }}</li>
     </ul>
     <ul>
      <li *ngIf="uname.untouched">Name is UnTouched</li>
      <li *ngIf="uname.touched">Name is Touched</li>
      <li *ngIf="uname.pristine">Name is Pristine</li>
      <li *ngIf="uname.dirty">Name is Dirty</li>
      <li *ngIf="uname.valid">Name is Valid</li>
      <li *ngIf="uname.invalid">Name is InValid</li>
     </ul>
     <ul>
      <li *ngIf="uage.untouched">Age is UnTouched</li>
      <li *ngIf="uage.touched">Age is Touched</li>
      <li *ngIf="uage.pristine">Age is Pristine</li>
      <li *ngIf="uage.dirty">Age is Dirty</li>
      <li *ngIf="uage.valid">Age is Valid</li>
      <li *ngIf="uage.invalid">Age is InValid</li>
     </ul>
     <ul>
      <li *ngIf="mail.untouched">eMail is UnTouched</li>
      <li *ngIf="mail.touched">eMail is Touched</li>
      <li *ngIf="mail.pristine">eMail is Pristine</li>
      <li *ngIf="mail.dirty">eMail is Dirty</li>
      <li *ngIf="mail.valid">eMail is Valid</li>
      <li *ngIf="mail.invalid">eMail is InValid</li>
     </ul>
     <ul>
      <li *ngIf="myform.untouched">User Form is UnTouched</li>
      <li *ngIf="myform.touched">User Form is Touched</li>
      <li *ngIf="myform.pristine">User Form is Pristine</li>
      <li *ngIf="myform.dirty">User Form is Dirty</li>
      <li *ngIf="myform.valid">User Form is Valid</li>
      <li *ngIf="myform.invalid">User Form is InValid</li>
     </ul>
    `,
     styles: [`
     .err{
       color : crimson;
     }
     input.ng-invalid.ng-touched{
       border : 5px solid crimson;
     }
     input.ng-valid.ng-touched{
       border : 5px solid darkseagreen;
     }
   `]
})
export class TemplateForm{
    userdata = {
        name : '',
        age : '',
        email : ''
      }
      formSubmitHandler(form:any, evt:any){
        evt.preventDefault();
        // console.log(form.controls.userage.value);
        if(form.controls.userage.value < 18){
          alert("you are too young to join us");
        }else if(form.controls.userage.value > 90){
          alert("you are too old to join us");
        }else{
          // alert("welcome to our company");
          evt.target.submit();
        }
      }
}