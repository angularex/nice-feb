import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
    selector : 'app-data-form',
    template : `
     <div>
      <h2>Reactive Driven Form</h2>
      <form  [formGroup]="userForm" action="#" method="get">
      <div class="mb-3">
          <label for="username" class="form-label">User Name</label>
          <input formControlName="username" name="username" class="form-control" id="username" >
          <div *ngIf="userForm.get('username').invalid && userForm.get('username').touched" class="form-text err">User Name is Invalid</div>
        </div>
        <div class="mb-3">
          <label for="userage" class="form-label">User Age</label>
          <input formControlName="userage" name="userage" type="number" class="form-control" id="userage" >
          <div *ngIf="userForm.get('userage').invalid && userForm.get('userage').touched && userForm.get('userage').value < 18" class="form-text err">You are too young to join us</div>
          <div *ngIf="userForm.get('userage').invalid && userForm.get('userage').touched && userForm.get('userage').value > 90" class="form-text err">You are too old to join us</div>
        </div>
        <div class="mb-3">
          <label for="useremail" class="form-label">Email address</label>
          <input formControlName="usermail" name="useremail" type="email" class="form-control" id="useremail" >
          <div *ngIf="userForm.get('usermail').invalid && userForm.get('usermail').touched" class="form-text err">eMail id is Invalid</div>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
        &nbsp;
        <button (click)="fillName()" class="btn btn-primary ">Fill Name</button>
        &nbsp;
        <button (click)="fillAllData()" class="btn btn-primary ">Fill Name / age / email</button>

      </form>
     </div> 
     <ul>
     <li>
          {{  userForm.get('username').value }}
          {{  userForm.get('userage').value }}
          {{  userForm.get('usermail').value }}
        </li>

     </ul>
     <ul>
      <li *ngIf="userForm.get('username').untouched">Name is UnTouched</li>
      <li *ngIf="userForm.get('username').touched">Name is Touched</li>
      <li *ngIf="userForm.get('username').pristine">Name is Pristine</li>
      <li *ngIf="userForm.get('username').dirty">Name is Dirty</li>
      <li *ngIf="userForm.get('username').valid">Name is Valid</li>
      <li *ngIf="userForm.get('username').invalid">Name is InValid</li>
     </ul>
     <ul>
      <li *ngIf="userForm.get('userage').untouched">Age is UnTouched</li>
      <li *ngIf="userForm.get('userage').touched">Age is Touched</li>
      <li *ngIf="userForm.get('userage').pristine">Age is Pristine</li>
      <li *ngIf="userForm.get('userage').dirty">Age is Dirty</li>
      <li *ngIf="userForm.get('userage').valid">Age is Valid</li>
      <li *ngIf="userForm.get('userage').invalid">Age is InValid</li>
     </ul>
     <ul>
      <li *ngIf="userForm.get('usermail').untouched">eMail is UnTouched</li>
      <li *ngIf="userForm.get('usermail').touched">eMail is Touched</li>
      <li *ngIf="userForm.get('usermail').pristine">eMail is Pristine</li>
      <li *ngIf="userForm.get('usermail').dirty">eMail is Dirty</li>
      <li *ngIf="userForm.get('usermail').valid">eMail is Valid</li>
      <li *ngIf="userForm.get('usermail').invalid">eMail is InValid</li>
     </ul>
     <ul>
      <li *ngIf="userForm.untouched">User Form is UnTouched</li>
      <li *ngIf="userForm.touched">User Form is Touched</li>
      <li *ngIf="userForm.pristine">User Form is Pristine</li>
      <li *ngIf="userForm.dirty">User Form is Dirty</li>
      <li *ngIf="userForm.valid">User Form is Valid</li>
      <li *ngIf="userForm.invalid">User Form is InValid</li>
     </ul>

    `,
     styles: [`
     .err{
       color : crimson;
     }
     input.ng-invalid.ng-touched{
       border : 5px solid crimson;
     }
     input.ng-valid.ng-touched{
       border : 5px solid darkseagreen;
     }
   `]
})
export class DataReactiveForm implements OnInit{
    userForm:any;
    constructor( private fb:FormBuilder){}
    ngOnInit(){
        this.userForm = this.fb.group({
            username : [ '', Validators.required ],
            userage : [ '', [Validators.required, Validators.min(18), Validators.max(90) ]],
            usermail : [ '', [Validators.required, Validators.pattern('.+@.+')] ]
        })
    }

    fillName(){
        this.userForm.patchValue({
            username : "Peter Parker"
        })
    }
    fillAllData(){
        this.userForm.setValue({
            username : "Peter Parker",
            userage : 20,
            usermail : "peter@parker.com",
        })
    }


}