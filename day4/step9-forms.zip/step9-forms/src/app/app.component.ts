import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Forms in Angular</h1>
      <app-temp-form></app-temp-form>
      <hr>
      <app-data-form></app-data-form>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step9-forms';
}
