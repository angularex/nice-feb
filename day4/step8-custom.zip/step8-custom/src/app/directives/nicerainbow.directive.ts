import { Directive, ElementRef, Input } from "@angular/core";
/* 
tag directive eg : nice 
attribute directive eg : [nice] 
*/
@Directive({
    selector : "[nice]",
})
export class NiceRainbow{
    @Input() nice:any = []
    constructor(private elRef:ElementRef){}
    ngOnInit(){
        // alert("nice was created")
        /* let temp = this.elRef.nativeElement.innerHTML;
        this.elRef.nativeElement.innerHTML = "<"+this.nice+">"+temp+"<"+this.nice+"/>"; */
        let temp = ""
        for(let i = 0; i < this.nice.length; i++){
            console.log(temp);
            temp += "<span>"+i+"</span> "+this.elRef.nativeElement.innerHTML+"<br/>";
        };
        this.elRef.nativeElement.innerHTML = temp;
    }
};

/*
tag directive
<ng-content>
<ng-template>

attribute directives
*ngFor
*ngIf
[ngSwitch]
[ngClass]
[ngStyle]
ngNonBindable
[(ngModel)]


*/