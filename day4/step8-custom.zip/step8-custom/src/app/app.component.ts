import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Customize Angular</h1>
    <hr>
    <app-box></app-box>
    <app-box></app-box>
    <app-box></app-box>
    <div style="clear: both;"></div>
    <p>{{ "Welcome" | count }} </p>
    <p>{{ "To" | count }} </p>
    <p>{{ "Your" | count }} </p>
    <p>{{ "Life" | count }} </p>
    <hr>

<!--     <p nice="h1">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iste tenetur, ex quibusdam dicta provident eius aliquid nesciunt. Dignissimos, deserunt accusantium distinctio nisi tempora, repudiandae in aperiam, animi earum repellendus unde.
    </p>
    <p nice="h3">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iste tenetur, ex quibusdam dicta provident eius aliquid nesciunt. Dignissimos, deserunt accusantium distinctio nisi tempora, repudiandae in aperiam, animi earum repellendus unde.
    </p>
    <p nice="button">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iste tenetur, ex quibusdam dicta provident eius aliquid nesciunt. Dignissimos, deserunt accusantium distinctio nisi tempora, repudiandae in aperiam, animi earum repellendus unde.
    </p> -->
    <p [nice]="heroes">
      Lorem
    </p>
    `,
  styles: []
})
export class AppComponent {
  title = 'step8-custom';
  heroes = ['ironman','hulk','thor','black widow']
}
