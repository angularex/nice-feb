import { NgModule } from '@angular/core';
import { BoxComp } from '../components/box.component';
import { NiceRainbow } from '../directives/nicerainbow.directive';
import { CountPipe } from '../pipes/count.pipe';
@NgModule({
    declarations : [BoxComp, CountPipe, NiceRainbow],
    exports : [BoxComp, CountPipe, NiceRainbow]
})
export class NiceModule { }