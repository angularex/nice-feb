import { Pipe } from "@angular/core";

@Pipe({
    name : "count"
})
export class CountPipe{
    transform(...args:any){
        return args[0]+" : "+args[0].length;
    }
}