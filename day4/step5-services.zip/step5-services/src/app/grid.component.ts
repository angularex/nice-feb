import { Component, Input } from '@angular/core';
import { Hero } from './hero.model';

@Component({
  selector: 'app-grid',
  template: `
    <table class="table table-striped table-sm">
    <thead class="table-dark">
      <tr>
        <th>Sl #</th>
        <th>Title</th>
        <th>Full Name</th>
        <th>Poster</th>
        <th>City</th>
        <th>Release Date</th>
        <th>Ticket Price</th>
        <th>Movies Count</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of heroeslist">
        <td>{{ hero.sl }}</td>
        <td>{{ hero.title }}</td>
        <td>{{ hero.firstname+" "+hero.lastname }}</td>
        <td>
          <img width="50" src="{{ hero.poster }}" alt="{{ hero.firstname+' '+hero.lastname }}">
        </td>
        <td>{{ hero.city }}</td>
        <td>{{ hero.releasedate | date : 'dd-MMMM-yyyy' }}</td>
        <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '0.2-3' }}</td>
        <td>{{ hero.movieslist.length }}</td>
      </tr>
    </tbody>
   </table>
  `,
  styles: [
  ]
})
export class GridComponent {
  @Input('data') heroeslist:Array<Hero> = [];
}
