import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  template: `
    <ul class="nav justify-content-center">
      <li class="nav-item"  *ngFor="let hero of heroeslist">
        <a class="nav-link" href="#">{{ hero.title }}</a>
      </li>
   </ul>
  `,
  styles: [
  ]
})
export class HeaderComponent {
  @Input('data') heroeslist:any;

 
}
