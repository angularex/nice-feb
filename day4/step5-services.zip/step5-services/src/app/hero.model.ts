export class Hero{
    sl:string = "";
    title:string = "";
    firstname:string = "";
    lastname:string = "";
    city:string = "";
    poster:string = "";
    releasedate:string = "";
    ticketprice:string = "";
    movieslist:Array<string> = [""];
}