let express = require("express");
let cors = require("cors");
let mongoose = require("mongoose");
let config = require("./config.json");
//----------------------------------
// configure modules / middleware
let app = express();
// request and response will now be json 
app.use(express.json());
// to avoid CORS Errors
app.use(cors());
//----------------------------------
// configure utilities
//----------------------------------
// configure database access
let path = config.url.replace("{{user}}",config.username).replace("{{pass}}", config.password);

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero", Schema({
        id : ObjectId,
        title : String,
        firstname : String,
        lastname : String,
        city : String
}));
mongoose.connect(path)
.then(res => console.log("DB Connected"))
.catch(error => console.log("Error ", error));

//----------------------------------
// configure routes to handle CRUD requests
//----------------------------------

// READ
app.get("/data", (req, res)=>{
    Hero.find().then(dbres => res.json( dbres ));
});

// CREATE
app.post("/data", (req, res)=>{
   let hero = new Hero(req.body);
   hero.save()
   .then(dbres => res.send({message : dbres.title+" was added"}))
   .catch(error => console.log(error));
});

// READ TO UPDATE
app.get("/edit/:hid", (req, res) => {
    Hero.findById(req.params.hid, (error, heroToEdit) => {
        if(error){console.log("Error", error)}
        else{
            res.json(heroToEdit);
        }
    })
});

// UPDATE
app.post("/edit/:hid", (req, res) => {
    Hero.findById(req.params.hid, (error, heroToEdit) => {
        if(error){console.log("Error", error)}
        else{
            heroToEdit.title = req.body.title;
            heroToEdit.firstname = req.body.firstname;
            heroToEdit.lastname = req.body.lastname;
            heroToEdit.city = req.body.city;
            heroToEdit.save()
            .then(dbres => res.send({ message : dbres }))
            .catch(error => console.log("Error ", error))
        }
    })
});

// DELETE
app.delete("/delete/:hid", (req, res)=>{
    Hero.findByIdAndDelete(req.params.hid, (error, deletedHero) => {
        if(error){ console.log( "Error ", error)}
        else{ res.send({ message : deletedHero.title+" was removed "})}
    })
})
// configure web server
//----------------------------------
app.listen(config.port,config.host, function(error){
    if(error){
        console.log("Error ", error)
    }else{
        console.log("server is now live on localhost:5050")
    }
})
